//
//  main.c
//  file_transfer_lab
//
//  Created by ????????? on 2021-09-22.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    // insert code here...cle
    printf("Hello, World Using VS code! \n");
    
    return 0;
}
